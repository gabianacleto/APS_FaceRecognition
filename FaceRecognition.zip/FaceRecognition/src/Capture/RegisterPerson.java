/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capture;

import Principal.Login;
import Util.ConectBan;
import Util.ControlPerson;
import Util.ModelPerson;
import java.io.File;
import java.io.InputStream;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Larissa
 */
public class RegisterPerson extends javax.swing.JFrame {

    ConectBan conecta = new ConectBan();
            
      ControlPerson cod;
      ModelPerson mod;
      
    public RegisterPerson() {
        initComponents();
        showIdUser();
         this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtFirst = new javax.swing.JTextField();
        txtAge = new javax.swing.JTextField();
        txtLast = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        lblID = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblCadastrar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtPhone = new javax.swing.JPanel();
        lblLogin = new javax.swing.JLabel();
        lblFotoDigital = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblCadastro = new javax.swing.JLabel();
        txtPhone1 = new javax.swing.JPanel();
        lblLogin1 = new javax.swing.JLabel();
        txtPhone2 = new javax.swing.JPanel();
        lblLogin2 = new javax.swing.JLabel();
        lblCaminho = new javax.swing.JLabel();
        txtPhone3 = new javax.swing.JPanel();
        lblLogin3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(txtFirst, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 160, 33));
        getContentPane().add(txtAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 160, 33));
        getContentPane().add(txtLast, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 160, 33));

        jLabel1.setFont(new java.awt.Font("Telegrafico", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Id do usuario:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 31));
        jLabel1.getAccessibleContext().setAccessibleName("ID do usuario:");

        lblID.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        lblID.setForeground(new java.awt.Color(255, 255, 255));
        lblID.setText("1");
        getContentPane().add(lblID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 50, 40));

        jLabel6.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(250, 250, 250));
        jLabel6.setText("Nome");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 90, 14));

        jLabel2.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(250, 250, 250));
        jLabel2.setText("Sobrenome");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 150, -1));

        jPanel2.setBackground(new java.awt.Color(187, 111, 235));

        lblCadastrar.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblCadastrar.setForeground(new java.awt.Color(250, 250, 250));
        lblCadastrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCadastrar.setText("Cadastrar");
        lblCadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCadastrarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCadastrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCadastrar, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 440, 210, 40));

        jLabel3.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(250, 250, 250));
        jLabel3.setText("Idade");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 230, -1));

        txtPhone.setBackground(new java.awt.Color(187, 111, 235));
        txtPhone.setFont(new java.awt.Font("Telegrafico", 0, 12)); // NOI18N
        txtPhone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPhoneMouseClicked(evt);
            }
        });

        lblLogin.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblLogin.setForeground(new java.awt.Color(255, 255, 255));
        lblLogin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogin.setText("enviar imagem");
        lblLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLoginMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout txtPhoneLayout = new javax.swing.GroupLayout(txtPhone);
        txtPhone.setLayout(txtPhoneLayout);
        txtPhoneLayout.setHorizontalGroup(
            txtPhoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhoneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        txtPhoneLayout.setVerticalGroup(
            txtPhoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, txtPhoneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(txtPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 130, 40));

        lblFotoDigital.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFotoDigital.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "DIGITAL", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Telegrafico", 0, 11), new java.awt.Color(250, 250, 250))); // NOI18N
        getContentPane().add(lblFotoDigital, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 130, 230));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\Lenovo ThinkPad\\Desktop\\FingerPrint\\fundo02.jpg")); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 520));

        jLabel8.setText("jLabel7");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, -1));

        jLabel9.setText("jLabel7");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, -1));

        lblCadastro.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblCadastro.setForeground(new java.awt.Color(250, 250, 250));
        lblCadastro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCadastro.setText("Cadastro");
        lblCadastro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCadastroMouseClicked(evt);
            }
        });
        getContentPane().add(lblCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        txtPhone1.setBackground(new java.awt.Color(187, 111, 235));
        txtPhone1.setFont(new java.awt.Font("Telegrafico", 0, 12)); // NOI18N
        txtPhone1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPhone1MouseClicked(evt);
            }
        });

        lblLogin1.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblLogin1.setForeground(new java.awt.Color(255, 255, 255));
        lblLogin1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogin1.setText("enviar imagem");
        lblLogin1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogin1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout txtPhone1Layout = new javax.swing.GroupLayout(txtPhone1);
        txtPhone1.setLayout(txtPhone1Layout);
        txtPhone1Layout.setHorizontalGroup(
            txtPhone1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhone1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin1, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                .addContainerGap())
        );
        txtPhone1Layout.setVerticalGroup(
            txtPhone1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhone1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(txtPhone1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 130, 40));

        txtPhone2.setBackground(new java.awt.Color(187, 111, 235));
        txtPhone2.setFont(new java.awt.Font("Telegrafico", 0, 12)); // NOI18N
        txtPhone2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPhone2MouseClicked(evt);
            }
        });

        lblLogin2.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblLogin2.setForeground(new java.awt.Color(255, 255, 255));
        lblLogin2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogin2.setText("enviar imagem");
        lblLogin2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogin2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout txtPhone2Layout = new javax.swing.GroupLayout(txtPhone2);
        txtPhone2.setLayout(txtPhone2Layout);
        txtPhone2Layout.setHorizontalGroup(
            txtPhone2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhone2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin2, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                .addContainerGap())
        );
        txtPhone2Layout.setVerticalGroup(
            txtPhone2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhone2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(txtPhone2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 130, 40));

        lblCaminho.setText("jLabel4");
        getContentPane().add(lblCaminho, new org.netbeans.lib.awtextra.AbsoluteConstraints(204, 210, 130, -1));

        txtPhone3.setBackground(new java.awt.Color(187, 111, 235));
        txtPhone3.setFont(new java.awt.Font("Telegrafico", 0, 12)); // NOI18N
        txtPhone3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPhone3MouseClicked(evt);
            }
        });

        lblLogin3.setFont(new java.awt.Font("Telegrafico", 0, 14)); // NOI18N
        lblLogin3.setForeground(new java.awt.Color(255, 255, 255));
        lblLogin3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogin3.setText("enviar imagem");
        lblLogin3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogin3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout txtPhone3Layout = new javax.swing.GroupLayout(txtPhone3);
        txtPhone3.setLayout(txtPhone3Layout);
        txtPhone3Layout.setHorizontalGroup(
            txtPhone3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtPhone3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogin3, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        txtPhone3Layout.setVerticalGroup(
            txtPhone3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, txtPhone3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogin3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(txtPhone3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 130, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblCadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCadastroMouseClicked
        cod = new ControlPerson();        
        mod = new ModelPerson();

        mod.setFirst_name(txtFirst.getText());
        mod.setLast_name(txtLast.getText());
        mod.setAge(txtAge.getText());
        mod.setImagem(lblCaminho.getText());

        cod.inserir(mod); 
           
        String fName = txtFirst.getText();
        String lName = txtLast.getText();
        String Imagem = lblCaminho.getText();
        String Age = txtAge.getText();
        int id = Integer.parseInt(lblID.getText());
        
        new Capture(id,fName,lName,Imagem,Age).setVisible(true);
    }//GEN-LAST:event_lblCadastroMouseClicked

    private void lblLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLoginMouseClicked
       
try{
            JFileChooser file = new JFileChooser();
            file.showOpenDialog(this);
            lblFotoDigital.setIcon(new ImageIcon(file.getSelectedFile().getPath()));
            String caminho = lblFotoDigital.getIcon().toString();  
            lblCaminho.setText(caminho); 
            System.out.println(caminho);
        }
        catch(Exception e){
            
        }
    }//GEN-LAST:event_lblLoginMouseClicked
 /*
    private void txtPhoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPhoneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneMouseClicked

    private void lblLogin1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogin1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblLogin1MouseClicked

    private void txtPhone1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPhone1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhone1MouseClicked

    private void lblLogin2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogin2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblLogin2MouseClicked

    private void txtPhone2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPhone2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhone2MouseClicked

    private void lblLogin3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogin3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblLogin3MouseClicked

    private void txtPhone3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPhone3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhone3MouseClicked
*/
    private void lblCadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCadastrarMouseClicked
     JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso!");
     Login logar = new Login();
     logar.setVisible(true);
     dispose();
    }//GEN-LAST:event_lblCadastrarMouseClicked

    private void txtPhoneMouseClicked(java.awt.event.MouseEvent evt) {                                      

    }/**/
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterPerson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterPerson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterPerson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterPerson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegisterPerson().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCadastrar;
    private javax.swing.JLabel lblCadastro;
    private javax.swing.JLabel lblCaminho;
    private javax.swing.JLabel lblFotoDigital;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblLogin;
    private javax.swing.JLabel lblLogin1;
    private javax.swing.JLabel lblLogin2;
    private javax.swing.JLabel lblLogin3;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtFirst;
    private javax.swing.JTextField txtLast;
    private javax.swing.JPanel txtPhone;
    private javax.swing.JPanel txtPhone1;
    private javax.swing.JPanel txtPhone2;
    private javax.swing.JPanel txtPhone3;
    // End of variables declaration//GEN-END:variables

    private void showIdUser() {
        conecta.conexao();
        try{
        conecta.executaSQL("SELECT * FROM person ORDER BY id DESC LIMIT 3");
        conecta.rs.first();
        lblID.setText(String.valueOf(conecta.rs.getInt("id")));
        int id = Integer.parseInt(lblID.getText());
        id++;
        lblID.setText(String.valueOf(id));

        }
        catch(Exception e){
        
        }
    }
}
