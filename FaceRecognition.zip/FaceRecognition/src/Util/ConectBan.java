
package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ConectBan {
    public Statement stm;
    
    public ResultSet rs;
    
    private final String driver = "org.mysql.Driver";
    private final String user = "jdbc:mysql://127.0.0.1/face_recognition";
    private final String root = "root";
    private final String pass = "";

    public Connection conn;
    
    public void conexao(){
        try{
            System.setProperty("jdbc.driver", driver);
            conn = DriverManager.getConnection(user, root, pass);
            System.out.println("GLÓRIA A DEUS");
        }  
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "Erro " + e);
        }
    }
    
    public void desconecta(){
        try{ 
            conn.close();
        }
        
        catch(SQLException e){           
        }
    }
    
    public void executaSQL(String SQL){
        try{ 
            stm = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stm.executeQuery(SQL);
        }
        
        catch(Exception e){      
            JOptionPane.showMessageDialog(null, "Erro " + e);
        }
    }
    
}
